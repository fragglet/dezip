/* DUMMY VERSION (no wildcards) */


/**********************/
/* Function do_wild() */
/**********************/

char *do_wild(wildspec)
    char *wildspec;         /* only used first time on a given dir */
{
    static char matchname[FILNAMSIZ];
    static int firstcall = TRUE;


    /* Even though we're just returning wildspec, we *always* do so in
     * matchname[]--calling routine is allowed to append four characters
     * to the returned string, and wildspec may be a pointer to argv[].
     */
    if (firstcall) {        /* first call:  must initialize everything */
        firstcall = FALSE;

        /* return the raw wildspec in case that works (e.g., directory not
         * searchable, but filespec was not wild and file is readable) */
        strcpy(matchname, wildspec);
        return matchname;
    }

    firstcall = TRUE;  /* reset for new wildspec */
    return (char *)NULL;

} /* end function do_wild() */
